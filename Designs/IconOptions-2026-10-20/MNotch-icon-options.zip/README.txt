MNotch icon options — 2026-10-20

01-peak: Núi M
02-notch: Notch tối giản
03-island: Đảo nổi

Mỗi thư mục gồm app-icon.png (bản gốc AI, có alpha), menubar.svg, menubar-template.pdf và PNG 18/36/54 px.
Menubar dùng template đơn sắc, tự đổi màu theo giao diện hệ thống. Khi tích hợp AppKit: isTemplate=true và size=18x18 pt.
index.html: trang so sánh. prompts.json: nguyên văn prompt ImageGen. render-menubar.swift: nguồn xuất vector/raster cho menubar.

App icons: built-in image_gen. Menubar: vector vẽ riêng, không dùng gradient ở kích thước nhỏ.
Đây là các phương án để chọn; chưa thay tài nguyên của ứng dụng đang cài.
